
-- --------------------------------------------------------

--
-- Table structure for table `Master`
--

CREATE TABLE `Master` (
  `player` varchar(250) NOT NULL,
  `faction` varchar(250) NOT NULL,
  `joined` mediumtext,
  `invitedby` varchar(280) DEFAULT NULL,
  `rank` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Master`
--

INSERT INTO `Master` (`player`, `faction`, `joined`, `invitedby`, `rank`) VALUES
('yungtechboy1', 'YungTechers', '1274457317930', NULL, 'Leader');
