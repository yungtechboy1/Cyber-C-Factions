
-- --------------------------------------------------------

--
-- Table structure for table `FactionInvites`
--

CREATE TABLE `FactionInvites` (
  `id` int(11) NOT NULL,
  `target` varchar(999) NOT NULL,
  `sender` varchar(999) DEFAULT NULL,
  `faction` varchar(999) DEFAULT NULL,
  `expires` varchar(999) NOT NULL,
  `rank` varchar(999) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
