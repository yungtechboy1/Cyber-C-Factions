
-- --------------------------------------------------------

--
-- Table structure for table `Ally`
--

CREATE TABLE `Ally` (
  `id` int(11) NOT NULL,
  `key` varchar(250) NOT NULL,
  `timestamp` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
