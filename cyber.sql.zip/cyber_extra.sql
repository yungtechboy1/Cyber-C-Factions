
--
-- Indexes for dumped tables
--

--
-- Indexes for table `ActiveMissions`
--
ALTER TABLE `ActiveMissions`
  ADD PRIMARY KEY (`faction`);

--
-- Indexes for table `Ally`
--
ALTER TABLE `Ally`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `Ally_key_uindex` (`key`);

--
-- Indexes for table `AuctionHouse`
--
ALTER TABLE `AuctionHouse`
  ADD PRIMARY KEY (`master_id`);

--
-- Indexes for table `confirm`
--
ALTER TABLE `confirm`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Enemy`
--
ALTER TABLE `Enemy`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `Enemy_key_uindex` (`key`);

--
-- Indexes for table `EPD`
--
ALTER TABLE `EPD`
  ADD PRIMARY KEY (`player`);

--
-- Indexes for table `FactionInvites`
--
ALTER TABLE `FactionInvites`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `id_2` (`id`);

--
-- Indexes for table `FactionInvitesAlly`
--
ALTER TABLE `FactionInvitesAlly`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Homes`
--
ALTER TABLE `Homes`
  ADD PRIMARY KEY (`homeid`);

--
-- Indexes for table `Master`
--
ALTER TABLE `Master`
  ADD PRIMARY KEY (`player`);

--
-- Indexes for table `Missions`
--
ALTER TABLE `Missions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `PlayerHomes`
--
ALTER TABLE `PlayerHomes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `PlayerSettings`
--
ALTER TABLE `PlayerSettings`
  ADD PRIMARY KEY (`Name`);

--
-- Indexes for table `plots`
--
ALTER TABLE `plots`
  ADD PRIMARY KEY (`plotid`),
  ADD UNIQUE KEY `plots_plotid_uindex` (`plotid`);

--
-- Indexes for table `relationship`
--
ALTER TABLE `relationship`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Requestes`
--
ALTER TABLE `Requestes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Settings`
--
ALTER TABLE `Settings`
  ADD PRIMARY KEY (`Name`),
  ADD UNIQUE KEY `Master_Name_uindex` (`Name`),
  ADD UNIQUE KEY `Master_displayname_uindex` (`DisplayName`);

--
-- Indexes for table `Warps`
--
ALTER TABLE `Warps`
  ADD PRIMARY KEY (`name`),
  ADD UNIQUE KEY `Warps_name_uindex` (`name`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Ally`
--
ALTER TABLE `Ally`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `AuctionHouse`
--
ALTER TABLE `AuctionHouse`
  MODIFY `master_id` int(250) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `confirm`
--
ALTER TABLE `confirm`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Enemy`
--
ALTER TABLE `Enemy`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `FactionInvites`
--
ALTER TABLE `FactionInvites`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `FactionInvitesAlly`
--
ALTER TABLE `FactionInvitesAlly`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Homes`
--
ALTER TABLE `Homes`
  MODIFY `homeid` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Missions`
--
ALTER TABLE `Missions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `PlayerHomes`
--
ALTER TABLE `PlayerHomes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;
--
-- AUTO_INCREMENT for table `relationship`
--
ALTER TABLE `relationship`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Requestes`
--
ALTER TABLE `Requestes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;