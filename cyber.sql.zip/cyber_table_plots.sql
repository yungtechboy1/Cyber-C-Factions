
-- --------------------------------------------------------

--
-- Table structure for table `plots`
--

CREATE TABLE `plots` (
  `plotid` varchar(10) NOT NULL,
  `faction` varchar(250) NOT NULL,
  `health` int(11) DEFAULT '2'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
