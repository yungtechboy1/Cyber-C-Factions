
-- --------------------------------------------------------

--
-- Table structure for table `Missions`
--

CREATE TABLE `Missions` (
  `id` int(11) NOT NULL,
  `Name` varchar(250) NOT NULL,
  `Description` varchar(250) DEFAULT NULL,
  `Break` varchar(999) DEFAULT NULL,
  `Place` varchar(999) DEFAULT NULL,
  `Item` varchar(999) DEFAULT NULL,
  `Kill` varchar(999) DEFAULT NULL,
  `Move` varchar(999) DEFAULT NULL,
  `column_9` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
