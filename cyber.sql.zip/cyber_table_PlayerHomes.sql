
-- --------------------------------------------------------

--
-- Table structure for table `PlayerHomes`
--

CREATE TABLE `PlayerHomes` (
  `id` int(11) NOT NULL,
  `name` varchar(999) NOT NULL,
  `x` double DEFAULT NULL,
  `y` double DEFAULT NULL,
  `z` double DEFAULT NULL,
  `level` varchar(999) DEFAULT NULL,
  `owner` varchar(200) DEFAULT NULL,
  `owneruuid` varchar(999) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
