
-- --------------------------------------------------------

--
-- Table structure for table `Requestes`
--

CREATE TABLE `Requestes` (
  `id` int(11) NOT NULL,
  `type` varchar(250) NOT NULL,
  `faction` varchar(250) DEFAULT NULL,
  `player` varchar(250) DEFAULT NULL,
  `target` varchar(250) NOT NULL,
  `expires` int(11) NOT NULL,
  `data` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
