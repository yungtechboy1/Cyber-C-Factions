
-- --------------------------------------------------------

--
-- Table structure for table `PlayerSettings`
--

CREATE TABLE `PlayerSettings` (
  `Name` varchar(250) NOT NULL,
  `UUIDs` varchar(999) DEFAULT NULL,
  `Cash` int(11) NOT NULL DEFAULT '0',
  `CreditScore` int(11) DEFAULT '650',
  `CreditLimit` int(11) NOT NULL DEFAULT '100',
  `UsedCredit` int(11) NOT NULL DEFAULT '0',
  `PlayerWarnings` varchar(9999) DEFAULT NULL,
  `PlayerTempBans` varchar(9999) DEFAULT NULL,
  `PlayerKicks` varchar(9999) DEFAULT NULL,
  `PlayerBans` varchar(9999) DEFAULT NULL,
  `Kills` int(11) DEFAULT NULL,
  `Deaths` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `PlayerSettings`
--

INSERT INTO `PlayerSettings` (`Name`, `UUIDs`, `Cash`, `CreditScore`, `CreditLimit`, `UsedCredit`, `PlayerWarnings`, `PlayerTempBans`, `PlayerKicks`, `PlayerBans`, `Kills`, `Deaths`) VALUES
('yungtechboy1', '[\"84920db2-6e5b-3728-abc6-0efc9b629023\"]', 1000, 350, 1000, 0, '[]', '[]', '[]', '[]', 0, 0);
