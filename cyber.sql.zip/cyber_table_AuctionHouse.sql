
-- --------------------------------------------------------

--
-- Table structure for table `AuctionHouse`
--

CREATE TABLE `AuctionHouse` (
  `master_id` int(250) NOT NULL,
  `item-id` int(250) NOT NULL,
  `item-meta` int(250) NOT NULL,
  `item-count` int(250) NOT NULL,
  `namedtag` blob NOT NULL,
  `cost` int(25) NOT NULL,
  `soldby` varchar(999) NOT NULL,
  `soldbyn` varchar(999) NOT NULL,
  `purchased` tinyint(1) NOT NULL DEFAULT '0',
  `moneysent` tinyint(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `AuctionHouse`
--

INSERT INTO `AuctionHouse` (`master_id`, `item-id`, `item-meta`, `item-count`, `namedtag`, `cost`, `soldby`, `soldbyn`, `purchased`, `moneysent`) VALUES
(2, 340, 0, 1, 0x0a000008030041504519004150457c416e7469646f7465506f7765727c53746167657c310a0700646973706c61790904004c6f726508040000000b00506f77657249443a2031360d00416e7469646f7465506f77657209005374616765203d20310f003d3d20414e5920434c415353203d3d0804004e616d650a00506f77657220426f6f6b000107006973506f7765720100, 10, '984cac61-b32c-3045-a7a7-fcf6f04214a3', 'CryingLeaf380', 0, 0),
(3, 139, 2, 64, '', 1000, '984cac61-b32c-3045-a7a7-fcf6f04214a3', 'CryingLeaf380', 0, 0);
