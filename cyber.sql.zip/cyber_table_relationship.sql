
-- --------------------------------------------------------

--
-- Table structure for table `relationship`
--

CREATE TABLE `relationship` (
  `id` int(11) NOT NULL,
  `type` varchar(250) NOT NULL,
  `factiona` varchar(250) NOT NULL,
  `target` varchar(250) NOT NULL,
  `time` int(15) NOT NULL,
  `inviter` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
