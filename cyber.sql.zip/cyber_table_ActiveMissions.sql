
-- --------------------------------------------------------

--
-- Table structure for table `ActiveMissions`
--

CREATE TABLE `ActiveMissions` (
  `faction` varchar(250) NOT NULL,
  `MissionID` int(11) NOT NULL,
  `timestamp` int(11) NOT NULL,
  `data` varchar(9999) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
