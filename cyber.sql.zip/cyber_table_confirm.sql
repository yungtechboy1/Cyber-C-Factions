
-- --------------------------------------------------------

--
-- Table structure for table `confirm`
--

CREATE TABLE `confirm` (
  `id` int(11) NOT NULL,
  `faction` varchar(250) NOT NULL,
  `player` varchar(250) NOT NULL,
  `time` int(20) NOT NULL,
  `invitedby` varchar(250) NOT NULL,
  `inviterank` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
