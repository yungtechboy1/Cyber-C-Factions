
-- --------------------------------------------------------

--
-- Table structure for table `Warps`
--

CREATE TABLE `Warps` (
  `name` varchar(250) NOT NULL,
  `x` int(11) DEFAULT NULL,
  `y` int(11) DEFAULT NULL,
  `z` int(11) DEFAULT NULL,
  `level` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
