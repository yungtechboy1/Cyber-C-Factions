
-- --------------------------------------------------------

--
-- Table structure for table `Enemy`
--

CREATE TABLE `Enemy` (
  `id` int(11) NOT NULL,
  `key` varchar(250) NOT NULL,
  `timestamp` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
