
-- --------------------------------------------------------

--
-- Table structure for table `Homes`
--

CREATE TABLE `Homes` (
  `homeid` int(11) NOT NULL,
  `x` int(11) NOT NULL,
  `y` int(11) NOT NULL,
  `z` int(11) NOT NULL,
  `level` int(11) NOT NULL,
  `faction` varchar(250) NOT NULL,
  `name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
