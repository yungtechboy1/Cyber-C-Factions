
-- --------------------------------------------------------

--
-- Table structure for table `Settings`
--

CREATE TABLE `Settings` (
  `Name` varchar(250) NOT NULL,
  `DisplayName` varchar(250) NOT NULL,
  `MaxPlayers` int(11) NOT NULL DEFAULT '10',
  `PowerBonus` double NOT NULL DEFAULT '1',
  `MOTD` varchar(250) DEFAULT NULL,
  `Description` varchar(250) DEFAULT NULL,
  `Privacy` int(11) NOT NULL DEFAULT '0',
  `Perm` text,
  `Power` int(11) DEFAULT NULL,
  `Money` int(11) DEFAULT NULL,
  `Rich` int(11) DEFAULT NULL,
  `XP` int(11) DEFAULT NULL,
  `Level` int(11) DEFAULT NULL,
  `Points` int(11) DEFAULT NULL,
  `MaxHomes` int(10) NOT NULL DEFAULT '3'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Settings`
--

INSERT INTO `Settings` (`Name`, `DisplayName`, `MaxPlayers`, `PowerBonus`, `MOTD`, `Description`, `Privacy`, `Perm`, `Power`, `Money`, `Rich`, `XP`, `Level`, `Points`, `MaxHomes`) VALUES
('peace', 'peace', 15, 1, 'Welcome! A basic faction message!', 'A Basis faction trying to win!', 0, '{\"AllowAlliesToTPToHomes\":true,\"AllowedToViewInbox\":{\"Id\":3},\"AllowedToAcceptAlly\":{\"Id\":3},\"AllowedToEditSettings\":{\"Id\":4},\"AllowedToPromote\":{\"Id\":1},\"AllowedToKick\":{\"Id\":3},\"MaxFactionChat\":30,\"MaxAllyChat\":30,\"WeeklyFactionTax\":0,\"AllowedToInvite\":{\"Id\":1},\"DefaultJoinRank\":{\"Id\":0},\"AllowedToClaim\":{\"Id\":3},\"AllowedToWinthdraw\":{\"Id\":3},\"AllowedToSetHome\":{\"Id\":3}}', 0, 0, 0, 0, 0, 0, 3),
('wilderness', 'wilderness', 15, 1, 'Welcome! A basic faction message!', 'A Basis faction trying to win!', 0, '{\"AllowAlliesToTPToHomes\":true,\"AllowedToViewInbox\":{\"Id\":3},\"AllowedToAcceptAlly\":{\"Id\":3},\"AllowedToEditSettings\":{\"Id\":4},\"AllowedToPromote\":{\"Id\":1},\"AllowedToKick\":{\"Id\":3},\"MaxFactionChat\":30,\"MaxAllyChat\":30,\"WeeklyFactionTax\":0,\"AllowedToInvite\":{\"Id\":1},\"DefaultJoinRank\":{\"Id\":0},\"AllowedToClaim\":{\"Id\":3},\"AllowedToWinthdraw\":{\"Id\":3},\"AllowedToSetHome\":{\"Id\":3}}', 0, 0, 0, 0, 0, 0, 3),
('YungTechers', 'YungTechers', 15, 1, 'Welcome! A basic faction message!', 'A Basis faction trying to win!', 0, '{\"AllowAlliesToTPToHomes\":true,\"AllowedToViewInbox\":{\"Id\":3},\"AllowedToAcceptAlly\":{\"Id\":3},\"AllowedToEditSettings\":{\"Id\":4},\"AllowedToPromote\":{\"Id\":1},\"AllowedToKick\":{\"Id\":3},\"MaxFactionChat\":30,\"MaxAllyChat\":30,\"WeeklyFactionTax\":0,\"AllowedToInvite\":{\"Id\":1},\"DefaultJoinRank\":{\"Id\":0},\"AllowedToClaim\":{\"Id\":3},\"AllowedToWinthdraw\":{\"Id\":3},\"AllowedToSetHome\":{\"Id\":3}}', 0, 0, 0, 0, 0, 0, 3);
