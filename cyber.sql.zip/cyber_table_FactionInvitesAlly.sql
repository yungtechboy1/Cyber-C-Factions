
-- --------------------------------------------------------

--
-- Table structure for table `FactionInvitesAlly`
--

CREATE TABLE `FactionInvitesAlly` (
  `id` int(11) NOT NULL,
  `target` varchar(999) NOT NULL,
  `faction` varchar(999) NOT NULL,
  `timeout` varchar(999) DEFAULT NULL,
  `sender` varchar(999) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
